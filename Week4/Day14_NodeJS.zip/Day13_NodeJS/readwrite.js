const fs = require('fs')

fs.rmdirSync('newDir')
fs.mkdirSync('newDir')

fs.mkdir('images',function(e){
    if(e){
        console.log(e)
    }
    console.log('Directory created successfully!')
})

// create a synchronous file using writeFileSync()
let filContent = 'This file has three names:\n1. Peter\n2. Martha\n3. Jason'
fs.writeFileSync('write.txt',filContent,'utf-8')

//create an asynchronous file using writefile
let msg = 'Welcome to nodejs IO files'
fs.writeFile('msg.txt',msg,'utf-8',function(e){
    if(e){
        console.log(e)
    }
})

// append information into an existing file
let addNames = '\n4. Georege\n5. Ann'
fs.appendFile('write.txt',addNames,'utf-8',function(error){
    if(error){
        console.log(error)
    }
})

//remove an existing file
fs.unlink('msg.txt',function(error){
    if(error){
        console.log(error)
    }
})

//asynchronous read module
console.log('Line before readFileSync')
fs.readFile('readme.txt','utf-8',function(error,data){
    console.log('\n\n-------------- asynch read file ---------------')
    console.log(data)
})

let sum = 5+20
console.log(`Sum = ${sum}`)
console.log('Line after readFileSync')


//synchronous read module
console.log('\n\nLine before readFileSync')
let fileRead = fs.readFileSync('readme.txt','utf-8')
console.log(fileRead)
console.log('Line after readFileSync')