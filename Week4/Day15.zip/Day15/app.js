// Streams and Buffers
const fs = require('fs')

//importing the http module
const http = require('http')

//Create a readable stream to read file readme.txt. This will fill up the buffer
// const readStream = fs.createReadStream('index.html')
const writestream = fs.createWriteStream('write.txt')

//creating a server
const server = http.createServer((request,response)=>{
    //sending the response 
    response.writeHead(200, { 'Content-Type': 'text/html' });

    const url = request.url
    if(url==='/home' || url==='/'){
        fs.createReadStream('index.html').pipe(response)
    }else if(url==='/about'){
        fs.createReadStream('about.html').pipe(response)
    }else{
        fs.createReadStream('404.html').pipe(response)
    }    
})

//serve listening to port 3000
server.listen((3000),()=>{
    console.log('Server is running at localhost:3000')
})

/*
//Listen to the stream and read file readme.txt. This will fill up the buffer:
readStream.on('data',(d)=>{
    console.log('\n ------------ new data received --------------- \n')
    console.log(d)
    console.log('\n ------------------------------------------------')
    writestream.write(d)
})

readStream.on('open',()=>{
    console.log('\n\nStream opened')
})

readStream.on('end',()=>{
    console.log('Stream closed!....\n\n')
})

//writestream
const writestream = fs.createWriteStream('write.txt')
writestream.write('Streaming text content','utf-8')


/*
//importing the http module
const http = require('http')

//creating a server
const server = http.createServer((request,response)=>{
    //sending the response
    response.write("This is the response from the server")
    response.end('\n------- end --------')
    console.log(request.url)
})

//serve listening to port 3000
server.listen((3000),()=>{
    console.log('Server is running at localhost:3000')
})
*/