// assert is used to compare two boolean values.
// It is used in mocha to test data before sending data to the db. If assert returns True, data will be sent to db
const assert = require('assert')
const Student = require('../src/students')

// create description function
describe('Create the first data', () =>{
    it('save the student',(done)=>{
        //create the new student
        const student1 = new Student({name:'Peter'})
        //read/save the new student in the db.
        student1.save()
        .then(()=>{
            assert(!student1.isNew)
            done()
        })
    })
})

 