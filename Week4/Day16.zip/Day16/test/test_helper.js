//import mongoose
const mongoose = require('mongoose')

//connect to database, students_test is the db name
mongoose.connect('mongodb://localhost/students_test')

//check if it is connected
mongoose.connection
//once method watches for mongoDB to connect the first time once an even occcurred
    .once('open',()=> {
        console.log('\n------------ Connected to mongoDB ---------------')
    })
        //on watches for error in the connection
    .on('error',(e)=>{
        console.log('Error connecting...',e)
    })
    
    //clear previous db actions
    beforeEach((done)=>{
    mongoose.connection.collections.students.drop()
    done()
    })