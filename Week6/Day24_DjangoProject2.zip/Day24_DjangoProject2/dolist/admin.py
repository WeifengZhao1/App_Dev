from django.contrib import admin
from . models import Todolist

# Register your models here.
admin.site.register(Todolist)