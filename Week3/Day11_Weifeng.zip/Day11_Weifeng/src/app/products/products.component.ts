import { Component } from "@angular/core";

@Component({
    selector:'products', //selecting a <product></product> tag
    templateUrl:'./products.component.html' //where am I going to find the selector
})

export class productsCompoent{

}