/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";

const User = function(props){
    return(
    <div class='comment'>
        <a href='' className='avator'>
            <img src={props.picture} alt="avator of office guy"/>
        </a>
        <div className="content">
            <a className='author'>
                {props.name}
            </a>
            <div className="metadata">
                <span className="date">Today at {props.date}</span>
            </div>
            <div className='text'>
                {props.msg}
            </div>
        </div>
    </div>
    )
}

export default User