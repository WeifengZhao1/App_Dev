import React from 'react';

const Cards = function (props) {
    return (
        <div className='cardContainer'>
            <div className='card'>
                <img src={props.picture} alt={props.alt} />
                <div className='cardContent'>
                    <p>{props.food}</p>
                    <p>{props.hover}</p>
                </div>
                <div className="slideMSG">{props.local}
                    <ul className='local'>
                        <li>{props.li1}</li>
                        <li>{props.li2}</li>
                        <li>{props.li3}</li>
                    </ul>
                </div>
            </div>
       </div>
    )
}

export default Cards;
