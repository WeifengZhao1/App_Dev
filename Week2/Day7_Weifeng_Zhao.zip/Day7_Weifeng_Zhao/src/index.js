/* eslint-disable react/jsx-pascal-case */
import React from 'react';
import ReactDOM from 'react-dom/client';
import User from './comments';
import an from './images/an.png';
import woman from './images/woman.png';
import read from './images/read.png'
import User_feedback from './UserFeedback';
import Cards from './card';
import dimsum from './images/dimsum.jpg'
import nyfood from './images/NY_food.jpg'
import milanfood from './images/Milan_food.jpg'
import tokyofood from './images/tokyo_food.jpg'

const App =function(){
  return(
    <div className='ui comments'>
      <User_feedback>
        <User 
          name='Ms.Lisa'
          date='09:30AM'
          msg="I'm feeling amazing"
          picture={woman}
      />
      </User_feedback>

      <User_feedback>
         
      <User 
        name='Ms.Lisa'
        date='09:30AM'
        msg="I'm feeling amazing"
        picture={read}
      />
      </User_feedback>

      <User_feedback>
        <User 
        name='Mrs.Alien'
        date='01:30AM' 
        msg="Where am I?" 
        picture={an}
        />
      </User_feedback>
      
      <div className="set2">
        <h1>Food</h1>
        <h3>Icon food of different Cities!</h3>
      </div>

      <div className='cardContainer'>
      <Cards
        picture={dimsum}
        alt='Dim Sum'
        food='Dim Sum'
        hover="Hover here to see local's favors restaurant"
        local="Local Favors Restaurant!"
        li1="Tsui Wah Restaurant"
        li2="Lin Heung Tea House"
        li3="Kau Kee Food Cafe"
      >
      </Cards>

      <Cards
        picture={nyfood}
        alt='Hot dog adnd Bagel'
        food='Hotdog & Bagel'
        hover="Hover here to see local's favors restaurant"
        local="Local Favors Restaurant!"
        li1="Joe's Pizza"
        li2="Ess-a-Bagel"
        li3="Di Fara Pizza"
      >
      </Cards>

      <Cards
        picture={milanfood}
        alt='Pizza & Pasta'
        food='Pizza & Pasta'
        hover="Hover here to see local's favors restaurant"
        local="Local Favors Restaurant!"
        li1="Da Giacomo"
        li2="Trattoria del Nuovo Macello"
        li3="La Pobbia 1850"
      >
      </Cards>

      <Cards
        picture={tokyofood}
        alt='Sushi'
        food='Sushi'
        hover="Hover here to see local's favors restaurant"
        local="Local Favors Restaurant!"
        li1="Sukiyabashi Jiro"
        li2="Sushi Dai"
        li3="Sushi Saito"
      >
      </Cards>
      </div>
    </div>
  )
}



//rooting
const root = ReactDOM.createRoot(document.querySelector('#root'))
root.render(App())

// const App = function(props){
//   return(
//     <div>
//       <h1>Welcome to React function components{props.name}</h1>
//     </div>
//   )
// }

// //create a props in a constant
// const myElement = <App name='Martha' />


// //rooting
// ReactDOM.render(
//   myElement,document.querySelector('#root'),
// )




