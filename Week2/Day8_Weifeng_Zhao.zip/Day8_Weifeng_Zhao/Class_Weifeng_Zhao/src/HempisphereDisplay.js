import React from "react";
import southernImg from './images/southern_hemisphere.jpg'
import norhternimg from './images/Northern_Hemisphere.png'
import equator from './images/equator-featured.jpg'

const Hemisphere_Display = (props) => {
    const hemisphereResult = props.latitude
    let userLocation = ''
    let picture
    if (hemisphereResult > 0) {
        userLocation = 'Northern Hemisphere!'
        picture=norhternimg
    }
    else if (hemisphereResult < 0) {
        userLocation = 'Southern Hemisphere!'
        picture=southernImg
    }
    else {
        userLocation = 'You are at the Ecuadorian line!'
        picture=equator
    }

    return (
        <div>
            <h1>Welcome to hemisphere app</h1>
            <p>You are at <span>{userLocation}</span></p>
            <img src={picture} alt="" style={{width:'50%'}}/>
        </div>
    )
}

export default Hemisphere_Display