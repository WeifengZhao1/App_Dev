import React from "react";
import { Outlet,Link } from "react-router-dom";

const Navbar = function(){
    return(
        <>
        <nav className="ui raised very padded segment">
            <a className="ui teal inverted segment" href={"https://www.qcc.cuny.edu"} target={"_blank"} rel="noreferrer">QCC</a>
            <div className="ui right floated header">
                <button className="ui button"> <Link to ="/">Home</Link></button>
                <button className="ui button"> <Link to ="/about">About us</Link></button>
                <button className="ui button"> <Link to ="/contact">Contact us</Link></button>
                <button className="ui button"> <Link to ="/form">Form</Link></button>
            </div>
        </nav>
        <Outlet/>
        </>
    )
}

export default Navbar